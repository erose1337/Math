import random

PARAMETERS = {'n' : 32}

def generate_key(parameters=PARAMETERS):
    n = parameters['n']
    key = [[0 for count in range(n)] for _ in range(n)]
    for i in range(n):
        key[i][i] = 1
    random.shuffle(key) # obviously insecure, testing purposes etc
    return key

def xorsum(*args):
    output = 0
    for item in args:
        output ^= item
    return output

def dotproduct(v1, v2):
    return sum(v1[i] * v2i for i, v2i in enumerate(v2))

def dotproduct2(v1, v2):
    return xorsum(*(v1[i] & v2[i] for i in range(len(v1))))

def mmul(m, v, dot=dotproduct2):
    try:
        return [dot(row, v) for row in m]
    except TypeError:
        return [[dot(row, _v) for row in m] for _v in v]

def scale_matrix(m, s):
    return [scale_vector(row, s) for row in m]

def scale_vector(v, s):
    return [x * s for x in v]

def add_matrix(m1, m2):
    return [add_vector(m1[i], m2[i]) for i in range(len(m1))]

def add_vector(v1, v2):
    return [v1[i] + v2[i] for i in range(len(v1))]

def F(k, v, dot=dotproduct):
    x = mmul(k, v, dot) # shuffle
    return dot(v, x) # dot product

def test_F():
    from utilities import random_integer
    from copy import deepcopy
    n = PARAMETERS['n']
    b = dotproduct2

    for count in range(256):
        K = generate_key()
        J = generate_key()
        KJ = add_matrix(K, J)

        # bits
        v = [random_integer(1) % 2 for _ in range(n)]
        KJ = add_matrix(K, J)
        assert F(K, v, b) ^ F(J, v, b) == F(KJ, v, b), (count, F(K, v, b), F(J, v, b), F(KJ, v, b))

        y = random_integer(1) % 2
        v2 = scale_vector(v, y)
        assert y * y * F(K, v, b) == F(K, v2, b), (count, y * y * F(K, v, b), F(K, v2, b))

        K2 = scale_matrix(K, y)
        assert y * F(K, v, b) == F(K2, v, b)

        # integers
        v = [random_integer(1) for _ in range(n)]
        assert F(K, v) + F(J, v) == F(KJ, v), (count, F(K, v), F(J, v), F(KJ, v))

        y = random_integer(1)
        v2 = scale_vector(v, y)
        assert y * y * F(K, v) == F(K, v2), (count, y * y * F(K, v), F(K, v2))

        K2 = scale_matrix(K, y)
        assert y * F(K, v) == F(K2, v)
        assert y * y * F(K, v) == F(scale_matrix(K2, y), v)

def test2():
    from utilities import random_integer
    def tobits(x):
        return [int(item) for item in format(x, 'b').zfill(32)]
    for counter in range(256):
        X = generate_key(); Y = generate_key();
        g = [random_integer(2) >> 2 for count in range(32)]
        pubx = tobits(F(X, g)); puby = tobits(F(Y, g))
        while len(pubx) != 32 or len(puby) != 32:
            g = [random_integer(2) >> 2 for count in range(32)]
            pubx = tobits(F(X, g)); puby = tobits(F(Y, g))
        assert F(X, puby, dotproduct2) == F(Y, pubx, dotproduct2), counter
        # relationship does not hold

if __name__ == "__main__":
    test_F()
    #test2()
